<?php
    define("SERVER", "your db server");
    define("USER", "your db username");
    define("PASSWORD", "your db passwrod");
    define("DATABASE", "your db");
?>